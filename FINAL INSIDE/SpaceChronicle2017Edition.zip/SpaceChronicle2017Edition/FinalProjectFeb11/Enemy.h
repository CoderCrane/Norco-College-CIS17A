#ifndef ENEMY_H
#define ENEMY_H
#include <string>

class Enemy {
private:

	std::string enemy;
	int health;
	int kick;
	int punch;
	int miss;

public:

	Enemy(int health, std::string name);
	std::string getEnemy();
	int getDamage(int choice);
	int getHealth();
	void setEnemy(std::string enemy);
	void setHealth(int newHealth);
	int getPunch();
	int getKick();
	int getMiss();
	void setPunch(int);
	void setKick(int);
	void setMiss(int);


};

#endif