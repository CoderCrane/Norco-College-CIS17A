#include "pch.h"  //INCLUDE IN 2017 EDITION
#include "PlainsStory.h"
#include <string>

PlainsStory::PlainsStory() {

	plainsOne = "Continuing your adventure, you leave the forest. Only to find out that the great plains are up ahead. \n[1]Continue traveling to the plains. ";
	//[1]Continue traveling to the plains
	plainsTwo = "When entering the plains, you encounter a space lion staring into your soul. He looks like\nhe hasn't eaten in days. What will you do?\n\n[1]Run away back into the forest.\n[2]Make loud noises in attempt to show no fear.\n";
	//[1]Scream at the lion
	plainsThree = "The space lion is annoyed by your antics but decided that you are not worth \nhis time. The lion leaves to find an easier kill. \n\n[1]Continue\n";
	//[2] Runaway
	plainsFour = " The space lion senses your fear and sees you as an easy kill. He catches up to you like nothing and you die. \n\n---------------\n   GAME OVER\n---------------";
	//[1] Coninue journey
	plainsFive = "As you continue walking you hear a rattle and you look down to see a vicious rattlesnake. It's slithering on your feet.\nWhat will you do to get out of this one? \n\n[1] Step on snake\n[2] Shoot snake with your pistol";
	//[1]Step on snake
	plainsSix = "\nYou step on the rattlesnake, but the snake laughs at your efforts. The snake proceeds to \n bite you on the leg. It's poision is extremely deadly so it kills you almost instantly.\n\n---------------\n   GAME OVER\n---------------";
	//[2]Shoot snake
	plainsSeven = "You attempt to shoot the snake, but you miss your first attempt. \nIt tries to strike you but it misses you as well. You gather yourself \nand attempt to shoot the snake again. You aim straight at its head and \nthe snake dies instantly. What do you want to do with the remains?\n\n[1] Eat the snake because you're hungry and curious. \n[2] Leave the remains and continue moving forward.\n";
	//[1]Eat snake
	plainsEight = "As you go in for a bite the snake is chewy but it's quite tasty. Despite its taste a few minutes later you start to \nfeel light headed. It seems like eating a space snake maybe isn't the best idea. You fall to your knees and then die.\n\n---------------\n   GAME OVER\n---------------";
	//[2]Leave snake
	plainsNine = "You continue on your journey and you just can't seem to catch a break. There's a space wolf \nthat is in the tall grass up ahead. However, the wolf hasn't seen you yet. You notice that it\nhas the final part to fix your ship and escape. What shall you do?\n \n[1]Sneak up on space wolf\n[2]Scream at the space wolf";
	//[1]Call the space wolf out
	plainsTen = "You scream at the space wolf to get his attention and he is not having \nany of it. The wolf rushes stright towards you. You must think fast\n\n[1]Attempt to pull out your gun\n[2]Punch the space wolf ";
	//[2]Sneak up to space wolf
	plainsEleven = "You slowly walk behind the space wolf, but accidently trip on a dead snake. It \nseems like the wolf may have found the snake you killed earlier and was snacking \non it. The wolf thinks you are trying to take it's food, so it kills you.\n\n---------------\n   GAME OVER\n---------------";
	//[1]pull out gun
	plainsTwelve = "You pull out your gun and start shooting frantically. You \nmiss every shot and end up runnning out of bullets. The space wolf attacks you and he isn't missing. \n\n---------------\n   GAME OVER\n---------------";
	plainsThirteen = "You throw a quick one two combo, but the space wolf dodges \nthem with ease. However, out of nowhere you throw a mean haymaker and \nit gets the wolf right on the jaw. The wolf is unconcious and \nyou get the final part that you needed for the ship.\n\n---------------\n   YOU WIN\n---------------";
}
std::string PlainsStory::getPlainsStoryOne() {
	return this->plainsOne;
}

void PlainsStory::setForestStoryOne(std::string newStory) {
	this->plainsOne;
}

std::string PlainsStory::getPlainsStoryTwo() {
	return this->plainsTwo;
}

void PlainsStory::setForestStoryTwo(std::string newStory) {
	this->plainsTwo;
}

std::string PlainsStory::getPlainsStoryThree() {
	return this->plainsThree;
}

void PlainsStory::setPlainsStoryThree(std::string newStory) {
	this->plainsThree;
}

std::string PlainsStory::getPlainsStoryFour() {
	return this->plainsFour;
}

void PlainsStory::setPlainsStoryFour(std::string newStory) {
	this->plainsFour;
}

std::string PlainsStory::getPlainsStoryFive() {
	return this->plainsFive;
}

void PlainsStory::setPlainsStoryFive(std::string newStory) {
	this->plainsFive;
}

std::string PlainsStory::getPlainsStorySix() {
	return this->plainsSix;
}

void PlainsStory::setPlainsStorySix(std::string newStory) {
	this->plainsSix;
}

std::string PlainsStory::getPlainsStorySeven() {
	return this->plainsSeven;
}

void PlainsStory::setPlainsStorySeven(std::string newStory) {
	this->plainsSeven;
}

std::string PlainsStory::getPlainsStoryEight() {
	return this->plainsEight;
}

void PlainsStory::setPlainsStoryEigth(std::string newStory) {
	this->plainsEight;
}

std::string PlainsStory::getPlainsStoryNine() {
	return this->plainsNine;
}

void PlainsStory::setPlainsStoryNine(std::string newStory) {
	this->plainsNine;
}

std::string PlainsStory::getPlainsStoryTen() {
	return this->plainsTen;
}

void PlainsStory::setPlainsStoryTen(std::string newStory) {
	this->plainsTen;
}

std::string PlainsStory::getPlainsStoryEleven() {
	return this->plainsEleven;
}

void PlainsStory::setPlainsStoryEleven(std::string newStory) {
	this->plainsEleven;
}

std::string PlainsStory::getPlainsStoryTwelve() {
	return this->plainsTwelve;
}

void PlainsStory::setPlainsStoryTwelve(std::string newStory) {
	this->plainsTwelve;
}

std::string PlainsStory::getPlainsStoryThirteen() {
	return this->plainsThirteen;
}

void PlainsStory::setPlainsStoryThirteen(std::string newStory) {
	this->plainsThirteen;
}
