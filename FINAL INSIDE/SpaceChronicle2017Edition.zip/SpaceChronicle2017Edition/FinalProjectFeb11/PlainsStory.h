//#include "pch.h"  INCLUDE IN 2017 EDITION
#ifndef PLAINs_STORY_H
#define PLAINS_STORY_H
#include <string>

class PlainsStory {
public:
	std::string plainsOne;
	std::string plainsTwo;
	std::string plainsThree;
	std::string plainsFour;
	std::string plainsFive;
	std::string plainsSix;
	std::string plainsSeven;
	std::string plainsEight;
	std::string plainsNine;
	std::string plainsTen;
	std::string plainsEleven;
	std::string plainsTwelve;
	std::string plainsThirteen;

	PlainsStory();

	std::string getPlainsStoryOne();
	void setForestStoryOne(std::string newStory);

	std::string getPlainsStoryTwo();
	void setForestStoryTwo(std::string newStory);

	std::string getPlainsStoryThree();
	void setPlainsStoryThree(std::string newStory);

	std::string getPlainsStoryFour();
	void setPlainsStoryFour(std::string newStory);

	std::string getPlainsStoryFive();
	void setPlainsStoryFive(std::string newStory);

	std::string getPlainsStorySix();
	void setPlainsStorySix(std::string newStory);

	std::string getPlainsStorySeven();
	void setPlainsStorySeven(std::string newStory);

	std::string getPlainsStoryEight();
	void setPlainsStoryEigth(std::string newStory);

	std::string getPlainsStoryNine();
	void setPlainsStoryNine(std::string newStory);

	std::string getPlainsStoryTen();
	void setPlainsStoryTen(std::string newStory);

	std::string getPlainsStoryEleven();
	void setPlainsStoryEleven(std::string newStory);

	std::string getPlainsStoryTwelve();
	void setPlainsStoryTwelve(std::string newStory);

	std::string getPlainsStoryThirteen();
	void setPlainsStoryThirteen(std::string newStory);
};

#endif
