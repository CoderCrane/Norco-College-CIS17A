#pragma once
//#include "pch.h"  INCLUDE IN 2017 EDITION
#include <string>

class ForestStory {
public:
	//Declare but do not initialize strings here.
	std::string forestOne;
	std::string forestTwo;
	std::string forestThree;
	std::string forestFour;
	std::string forestFive;
	std::string forestFiveOne;
	std::string forestFiveTwo;
	std::string forestFiveTwoOne;
	std::string forestFiveTwoTwo;
	std::string forestFiveTwoThree;
	std::string forestFiveThree;
	std::string forestFiveThreeOne;
	std::string forestFiveThreeTwo;

	ForestStory();

	std::string getForestStoryOne();
	void setForestStoryOne(std::string newForestStory);

	std::string getForestStoryTwo();
	void setForestStoryTwo(std::string newForestStory);

	std::string getForestStoryThree();
	void setForestStoryThree(std::string newForestStory);

	std::string getForestStoryFour();
	void setForestStoryFour(std::string newForestStory);

	std::string getForestStoryFive();
	void setForestStoryFive(std::string newForestStory);

	std::string getForestStoryFiveOne();
	void setForestStoryFiveOne(std::string newForestStory);

	std::string getForestStoryFiveTwo();
	void setForestStoryFiveTwo(std::string newForestStory);

	std::string getForestStoryFiveTwoOne();
	void setForestStoryFiveTwoOne(std::string newForestStory);

	std::string getForestStoryFiveTwoTwo();
	void setForestStoryFiveTwoTwo(std::string newForestStory);

	std::string getForestStoryFiveTwoThree();
	void setForestStoryFiveTwoThree(std::string newForestStory);

	std::string getForestStoryFiveThree();
	void setForestStoryFiveThree(std::string newForestStory);

	std::string getForestStoryFiveThreeOne();
	void setForestStoryFiveThreeOne(std::string newForestStory);

	std::string getForestStoryFiveThreeTwo();
	void setForestStoryFiveThreeTwo(std::string newForestStory);
};

// IN MAIN CODE LIKE SO:
//	ForestStory a;
//
//std::cout << a.getForestStory() << std::endl;