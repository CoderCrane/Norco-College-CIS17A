#pragma once
//the h file
#include "pch.h"
#include <string>

#ifndef INVENTORY_H
#define INVENTORY_H


class Inventory {
private:

	bool medKit;
	bool shipPart;
	bool fusionPistol;
	bool laserRifle;
	bool thermalCannon;

public:
	Inventory();		//To initialize the items and strings

	//medical kit 
	bool getMedKit();
	void setMedKit(bool newMedKit);

	//ship part
	bool getShipPart();
	void setShipPart(bool newShipPart);

	//fusion pistol
	bool getFusionPistol();
	void setFusionPart(bool newFusionPart);

	//laser rifle
	bool getLaserRifle();
	void setLaserRifle(bool newLaserRifle);

	//thermal cannon
	bool getThermalCannon();
	void setThermalCannon(bool newThermalCannon);

};


#endif // !INVENTORY_H