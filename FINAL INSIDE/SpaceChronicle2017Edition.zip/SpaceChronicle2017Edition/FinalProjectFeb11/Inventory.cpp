//the cpp file
#include "pch.h"
#include "Inventory.h"
#include <string>
#include <iostream>

Inventory::Inventory() {
	//this will initialize all items
	medKit = false;
	shipPart = false;
	fusionPistol = false;
	laserRifle = false;
	thermalCannon = false;

}

//medical kit
bool Inventory::getMedKit() {
	return this->medKit;
}
void Inventory::setMedKit(bool newMedKit) {
	this->medKit = newMedKit;
}

//ship part
bool Inventory::getShipPart() {
	return this->shipPart;
}
void Inventory::setShipPart(bool newShipPart) {
	this->shipPart = newShipPart;
}

//fusion pistol
bool Inventory::getFusionPistol() {
	return this->fusionPistol;
}
void Inventory::setFusionPart(bool newFusionPart) {
	this->fusionPistol = newFusionPart;
}

//laser rifle
bool Inventory::getLaserRifle() {
	return this->laserRifle;
}
void Inventory::setLaserRifle(bool newLaserRifle) {
	this->laserRifle = newLaserRifle;
}

//thermal cannon
bool Inventory::getThermalCannon() {
	return this->thermalCannon;
}
void Inventory::setThermalCannon(bool newThermalCannon) {
	this->thermalCannon = newThermalCannon;
}