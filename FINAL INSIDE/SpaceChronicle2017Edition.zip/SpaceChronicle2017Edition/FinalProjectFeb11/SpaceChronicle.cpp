#include "pch.h"
#include "ForestStory.h"
#include "PlainsStory.h"
#include "Inventory.h"
#include "Enemy.h"
#include <iostream>
#include <string>
#include <random>


int main()
{
	//possible classes
	int choice;
	int secondChoice;
	int thirdChoice;
	int fourthChoice;
	int fifthChoice;
	int sixthChoice;
	int seventhChoice;
	int eigthChoice;
	int ninthChoice;
	int tenthChoice;
	int eleventhChoice;
	int continueJourney;
	std::string pName;
	std::string pistol;
	int medkits = 0;
	int health = 100;
	int humanHealth = 100;
	int enemyHealth = 50;
	int playerinput;
	int shipParts = 3;
	bool continueAdventure = true;
	ForestStory a;
	Enemy y(50, "Groot");
	Inventory h;

	//#include <random>
	std::random_device rd;
	std::mt19937 getrand(rd());
	std::uniform_int_distribution<> distr(1, 3);

	//plains section
	PlainsStory b;
	int choice1;
	int choice2;
	int choice3;
	int choice4;
	int choice5;
	int choice6;
	int choice7;
	int choice8;

	//Menu.
	std::cout << "----------Welcome to Space Chronicle!----------\n"
		<< "|		[1] Start Game                |\n"
		<< "|		[2] Exit                      |\n"
		<< "-----------------------------------------------\n\n";

	std::cin >> choice;

	//data confirmation.
	while (choice < 1 || choice > 2) {
		std::cout << "Please enter 1 or 2." << std::endl;
		std::cin >> choice;
	}

	//if statement for Menu choice 1 or 2.
	if (choice == 1) {
		system("cls"); //clears the console.

		//prompt user for name.
		std::cout << "What is your name?" << std::endl;
		std::cin.ignore();
		std::getline(std::cin, pName);

		//prompt user for gender.
		std::cout << "\nAre you Male or Female?\n[1]Male\n[2]Female" << std::endl;
		std::cin >> choice;

		//if statement following 1, Male choice.
		if (choice == 1) {
			std::cout << "\nMale, strong and bold.  " << pName << ", will your actions in this journey prove so?\n[1] Continue" << std::endl;
			std::cin >> choice;
		}
		//else if following 2, Female choice.
		else if (choice == 2) {
			std::cout << "\nFemale, elegant and cunning.  " << pName << ", will your actions in this journey prove so?\n[1] Continue" << std::endl;
			std::cin >> choice;
		}

	}
	//Exit option.
	else if (choice == 2) {
		std::cout << "\nSpace Chronicle has ended.\n\n";
		return 0;
	}

	//Menu options are now finished.  The story now begins.
	system("cls"); //clears the console.
	std::cout << "You awake to flashing lights and an eerie siren.  Something is very wrong."
		<< "\nJumping to your feet you see your ship's main console."
		<< "\nWhat do you chose to do?\n[1]Go to console\n[2]Check inventory\n[3]Observe surroundings" << std::endl;
	std::cin >> choice;

	//switch statement based off user input options.
	switch (choice) {
		//result of Go to console
	case 1:
		system("cls"); //clears the console.
		std::cout << "The console flashes and an overhead communications system vaguely repeats a message:\n"
			<< "Engine temperatures critical.  Shields are offline.  Power structure failing.\n"
			<< "Recommended actions: Repair ship or evacuate.\nFrom the console a cracked window rests weakly."
			<< "You see a planet close by."
			<< "  What do you want to do?\n[1]Go to planet\n[2]Check inventory\n[3]Wait on ship" << std::endl;  //INCLUDE CHOICES 2 AND 3 AFTER GOING TO CONSOLE AS FIRST CHOICE
		std::cin >> choice;

		//[1]Go to planet
		if (choice == 1) {
			system("cls"); //clears the console.
			std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
				<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
				<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
				<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
				<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
			std::cin >> choice;
			break;
		}

		//[2]Check inventory
		if (choice == 2) {
			system("cls"); //clears the console.
			std::cout << "-----Inventory-----\n"
				<< "Health: " << health
				<< "\nMedkits: " << medkits
				<< "\nItems: Fusion pistol"
				<< "\n-------------------\n"
				<< "[1]To use a medkit\n[2]To exit inventory" << std::endl;
			std::cin >> secondChoice;

			//[1]To use a medkit
			if (secondChoice == 1) {
				if (medkits <= 0) {
					std::cout << "You have no medkits to use."
						<< "\n[1]Exit inventory" << std::endl;
					std::cin >> choice;
					system("cls"); //clears the console.
					std::cout << "[1]Go to planet" << std::endl;
					std::cin >> choice;
					system("cls"); //clears the console.
					std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
						<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
						<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
						<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
						<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
					std::cin >> choice;
					break;
				}
				else if (health >= 100) {
					std::cout << "You already have full health."
						<< "\n[1]Exit inventory" << std::endl;
					std::cin >> choice;
					system("cls"); //clears the console.
					std::cout << "[1]Go to planet" << std::endl;
					std::cin >> choice;
					system("cls"); //clears the console.
					std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
						<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
						<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
						<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
						<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
					std::cin >> choice;
					break;
				}
			}

			if (secondChoice == 2) {
				system("cls"); //clears the console.
				std::cout << "[1]Go to planet" << std::endl;
				std::cin >> choice;
				system("cls"); //clears the console.
				std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
					<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
					<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
					<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
					<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
				std::cin >> choice;
				break;
			}
		}

		//[3]Wait on ship
		if (choice == 3) {
			std::cout << "As you ponder over your ship's conditions, smoke begins to rise throughout the room.\nLights are fading."
				<< "You should not wait much longer.\nWhat do you want to do?\n[1]Go to planet\n[2]Wait longer" << std::endl;
			std::cin >> thirdChoice;
			if (thirdChoice == 1) {
				system("cls"); //clears the console.
				std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
					<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
					<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
					<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
					<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
				std::cin >> choice;
				break;
			}
			if (thirdChoice == 2) {
				std::cout << "The ship begins to make an ominous creak, and before you can react the icy cold of space surrounds you.\nYou have failed this Chronicle, but you always try again."
					<< "\n\n---------------\n"
					<< "   GAME OVER\n"
					<< "---------------" << std::endl;
				continueAdventure = false;
			}
			break;
		}

	case 2:
		system("cls"); //clears the console.
		std::cout << "-----Inventory-----\n"
			<< "Health: " << health
			<< "\nMedkits: " << medkits
			<< "\nItems: Fusion pistol"
			<< "\n-------------------\n"
			<< "[1]To use a medkit\n[2]To exit inventory" << std::endl;
		std::cin >> choice;

		//system which checks if user has medkits to use
		if (choice == 1) {
			if (medkits <= 0) {
				std::cout << "You have no medkits to use."
					<< "\n[1]Exit inventory" << std::endl;
				std::cin >> choice;
				system("cls"); //clears the console.
				std::cout << "[1]Go to planet" << std::endl;
				std::cin >> choice;
				system("cls"); //clears the console.
				std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
					<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
					<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
					<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
					<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
				std::cin >> choice;
				break;
			}
			else if (health >= 100) {
				std::cout << "You already have full health."
					<< "\n[1]Exit inventory" << std::endl;
				std::cin >> choice;
				system("cls"); //clears the console.
				std::cout << "[1]Go to planet" << std::endl;
				std::cin >> choice;
				system("cls"); //clears the console.
				std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
					<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
					<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
					<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
					<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
				std::cin >> choice;
				break;
			}
		}
		if (choice == 2) {
			system("cls"); //clears the console.
			std::cout << "[1]Go to planet." << std::endl;
			std::cin >> choice;
			system("cls"); //clears the console.
			std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
				<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
				<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
				<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
				<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
			std::cin >> choice;
			break;
		}

		break;
	case 3:
		std::cout << "As you ponder over your ship's conditions, smoke begins to rise throughout the room.\nLights are fading."
			<< "You should not wait much longer.\nWhat do you want to do?\n[1]Go to planet\n[2]Wait longer" << std::endl;
		std::cin >> choice;
		if (choice == 1) {
			system("cls"); //clears the console.
			std::cout << "You use the last of your ship's fuel to head towards the nearby planet.  The planet has a thick fog throughout"
				<< "\nits atmosphere, and appears to have red and green terrain.  As you get closer to the surface your ship stalls,"
				<< "\nand lands with an ubrupt thud.  You force open your ship's door and are greeted by a foreign biome teeming"
				<< "\nwith life.  The dirt is red and the foliage is a bright green.  Before you lies a swamp, beyond"
				<< "\nthe surrounding area is hard to envision.\n[1]Go to the swamp" << std::endl;
			std::cin >> choice;
			break;
		}
		if (choice == 2) {
			std::cout << "The ship begins to make an ominous creak, and before you can react the icy cold of space surrounds you.\nYou have failed this Chronicle, but you always try again."
				<< "\n\n---------------\n"
				<< "   GAME OVER\n"
				<< "---------------" << std::endl;
			continueAdventure = false;
		}
		break;
	}

	//[1]Go to the swamp
	switch (choice) {
	case 1:
		if (choice == 1) {
			system("cls"); //clears the console.
			std::cout << "Approaching the swamp, the gound becomes softer and a sour aroma fills the air amongst thick fog.  Checking your"
				<< "\nsurroundings in the swamp is difficult and you are not sure which way you've come from."
				<< "\nAround you appears to be the remains of a previous visitor.  It appears as if they shared a similar"
				<< "\njourney as yours, but much earlier in time.  Muddy steel and fungus covered wreckage rest throughout the"
				<< "\nforeboding waters.\n\n[1]Search more of the swamp" << std::endl;
			std::cin >> choice;
		}
		//[1]Search more of the swamp
		if (choice == 1) {
			system("cls"); //clears the console.
			std::cout << "Carefully moving forward, you spy a small ship cockpit with its door facing upright beyond thick fog surrounding"
				<< "\nyou.  The obscure peice of wreckage is half submerged in thick sludge.  The door is linedwith several "
				<< "\nforeign plants, and its window is cracked.  Inside you can see a part you could use for your ship."
				<< "\nWhat do you want to do?\n[1]Force open the door\n[2]Break the window and reach for the part" << std::endl;
			std::cin >> secondChoice;

			//[1]Force open the door
			if (secondChoice == 1) {
				system("cls"); //clears the console.
				std::cout << "You grab the door by its plant covered handle and pull.  Just before you think there is no use, the vines"
					<< "\nsnap back with force and the door flies open with a loud creak!  Inside you can hardly make out much, but"
					<< "\nyou can one of 3 peices you need to repair your ship.  What do you want to do?\n[1]Examine the cockpit more\n[2]Reach for the part" << std::endl;
				std::cin >> thirdChoice;

				//[1]Examine the cockpit more
				if (thirdChoice == 1) {
					std::cout << "\nAs you look closer there appears to be some kind of alien plant life living inside the dark"
						<< "\ncorners of the cockpit, and it doesn't look friendly.  What do you want to do?\n[1]Use your fusion pistol to shoot the plant\n[2]Reach for the part" << std::endl;
					std::cin >> fourthChoice;

					//[1]Use your fusion pistol to shoot the plant
					if (fourthChoice == 1) {
						std::cout << "\nYou pull your fusion pistol out and make quick work of whatever horrors lived inside of the cockpit."
							<< "\nIt looks safe to take the ship part you need.  After this, only " << shipParts - 1 << " more are needed."
							<< "\nAfter taking the part, the weather has reluctantly cleared up and you can make your way back.\n[1]Continue adventure" << std::endl;
						std::cin >> fifthChoice;
						//finished this course of swamp.
						break;
					}

					//[2]Reach for the part
					if (fourthChoice == 2) {
						std::cout << "\nJust as you feel for the part, something grabs your arms from inside the cockpit!  You struggle with your hands around"
							<< "\nthe part as you step out of the cockpit you find the alien plant life has grabbed onto your arm and continues to grasp"
							<< "\ntighter!  What do you want to do?\n[1]Go to the water and drown the plant\n[2]Use your fusion pistol to shoot the plant" << std::endl;
						std::cin >> fifthChoice;

						//[1]Go to the water and drown the plant
						if (fifthChoice == 1) {
							std::cout << "\nAs you struggle with the wriggling plant, you dive your arm into the thick bog.  The plant has abruply stopped, but you\nsoon find"
								<< " out why.  A burning sensation unlike anything you've felt before covers your entire arm.  As you pull your\narm out you stare in horror."
								<< "  What was once your arm has now begun rapidly dissolving due to the toxic swamp water.\nThe last few moments you recall are seeing the"
								<< " bone from beneath your flesh and space suit.  You cannot\nbare any more...your eyes slowly close.  You have failed this Chronicle, but you always try again."
								<< "\n\n---------------\n"
								<< "   GAME OVER\n"
								<< "---------------" << std::endl;
							continueAdventure = false;

						}
						break;

						//[2]Use your fusion pistol to shoot the plant
						if (fifthChoice == 2) {
							std::cout << "\nYou pull your fusion pistol out and make quick work of whatever horrors lived inside of the cockpit."
								<< "\nIt looks safe to take the ship part you need.  After this, only " << shipParts - 1 << " more are needed."
								<< "\nAfter taking the part, the weather has reluctantly cleared up and you can make your way back.\n[1]Continue adventure" << std::endl;
							std::cin >> sixthChoice;
							//finished this course of swamp.
						}
						break;
					}
				}

				//[2]Reach for the part
				if (thirdChoice == 2) {
					std::cout << "\nJust as you feel for the part, something grabs your arms from inside the cockpit!  You struggle with your hands around"
						<< "\nthe part as you step out of the cockpit you find the alien plant life has grabbed onto your arm and continues to grasp"
						<< "\ntighter!  What do you want to do?\n[1]Go to the water and drown the plant\n[2]Use your fusion pistol to shoot the plant" << std::endl;
					std::cin >> fourthChoice;

					//[1]Go to the water and drown the plant
					if (fourthChoice == 1) {
						std::cout << "\nAs you struggle with the wriggling plant, you dive your arm into the thick bog.  The plant has abruply stopped, but you\nsoon find"
							<< " out why.  A burning sensation unlike anything you've felt before covers your entire arm.  As you pull your\narm out you stare in horror."
							<< "  What was once your arm has now begun rapidly dissolving due to the toxic swamp water.\nThe last few moments you recall are seeing the"
							<< " bone from beneath your flesh and space suit.  You cannot\nbare any more...your eyes slowly close.  You have failed this Chronicle, but you always try again."
							<< "\n\n---------------\n"
							<< "   GAME OVER\n"
							<< "---------------" << std::endl;
						continueAdventure = false;

					}
					break;

					//[2]Use your fusion pistol to shoot the plant
					if (fourthChoice == 2) {
						std::cout << "\nYou pull your fusion pistol out and make quick work of whatever horrors lived inside of the cockpit."
							<< "\nIt looks safe to take the ship part you need.  After this, only " << shipParts - 1 << " more are needed."
							<< "\nAfter taking the part, the weather has reluctantly cleared up and you can make your way back.\n[1]Continue adventure" << std::endl;
						std::cin >> fifthChoice;
						//finished this course of swamp.
					}
					break;
				}

			}
			//choice [2]Break the window and reach for the part
			if (secondChoice == 2) {
				system("cls"); //clears the console.
				std::cout << "You pick up a rock and break the cracked window.  It did not have much strength thanks to the ship's crash long ago."
					<< "\nYou reach inside and need to lean forward completely through the window to get a feel for the ship part."
					<< "\nJust as you feel for the part, something grabs your arms from inside the cockpit!  You struggle with your hands around"
					<< "\nthe part and feel a sharp pain draw across your left forearm as you pull out of the window.  Some form of alien plant"
					<< "\nlife has grabbed onto your arm and continues to grasp tighter!  What do you want to do?\n[1]Go to the water and drown the plant\n[2]Use your fusion pistol to shoot the plant" << std::endl;
				std::cin >> thirdChoice;

				//[1]Go to the water and drown the plant
				if (thirdChoice == 1) {
					std::cout << "\nAs you struggle with the wriggling plant, you dive your arm into the thick bog.  The plant has abruply stopped, but you\nsoon find"
						<< " out why.  A burning sensation unlike anything you've felt before covers your entire arm.  As you pull your\narm out you stare in horror."
						<< "  What was once your arm has now begun rapidly dissolving due to the toxic swamp water.\nThe last few moments you recall are seeing the"
						<< " bone from beneath your flesh and space suit.  You cannot\nbare any more...your eyes slowly close.  You have failed this Chronicle, but you always try again."
						<< "\n\n---------------\n"
						<< "   GAME OVER\n"
						<< "---------------" << std::endl;
					continueAdventure = false;

				}

				//[2]Use your fusion pistol to shoot the plant
				if (thirdChoice == 2) {
					std::cout << "\nYou pull your fusion pistol out and make quick work of whatever horrors lived inside of the cockpit."
						<< "\nIt looks safe to take the ship part you need.  After this, only " << shipParts - 1 << " more are needed."
						<< "\nAfter taking the part, the weather has reluctantly cleared up and you can make your way back.\n[1]Continue adventure" << std::endl;
					std::cin >> fourthChoice;
					//finished this course of swamp.

				}
				break;
			}
			break;
		}
		break;
	}
	// 2/3/20 SWAMP is now complete, must do forest and plains.  Still need to incorportate battles.

	// 2/4/20 begin FOREST adventure
	//the see the part but need to get it by traveling into the forest, a creature has it.  they must chase the creature but need help to get it.
	//you will meet a space hunter who tells you how to track down the creature with the part, he gives you a medkit too.  After you get the part he thanks you for ridding the evil
	//of the forest, and in return gives you his lazer rifle, as he wont be needing it anymore--being the forest is safe again.

	if (continueAdventure == true) {
		switch (choice) {
		case 1:
			system("cls"); //clears the console.
			std::cout << a.getForestStoryOne() << std::endl;
			std::cin >> choice;

			//[1]Continue traveling to forest
			if (choice == 1) {
				system("cls"); //clears the console.
				std::cout << a.getForestStoryTwo() << std::endl;
				std::cin >> secondChoice;

				//[1]Pursue the beast
				if (secondChoice == 1) {
					system("cls"); //clears the console.
					std::cout << a.getForestStoryThree() << std::endl;
					std::cin >> thirdChoice;

					//[1]Enter battle
					if (thirdChoice == 1) {
						system("cls"); //clears the console.					


						do {

							int playerinput;

							//ENEMY TURN

							choice = distr(getrand);

							if (choice == 1) {
								std::cout << "You have encountered a " << y.getEnemy() << " it has ";
								std::cout << enemyHealth;
								std::cout << " health.";
								std::cout << " The " << y.getEnemy() << " has punched for 15 damage! " << std::endl;
								std::cout << std::endl;
								humanHealth = humanHealth - y.getDamage(1);
								std::cout << "You have been punched, you now have " << humanHealth << " health" << std::endl << std::endl;
							}
							else if (choice == 2) {
								std::cout << "You have encountered a " << y.getEnemy() << " it has ";
								std::cout << enemyHealth;
								std::cout << " health.";
								std::cout << " The " << y.getEnemy() << " has kicked for 20 damage! " << std::endl;
								std::cout << std::endl;
								humanHealth = humanHealth - y.getDamage(2);
								std::cout << "You have been kicked, you now have " << humanHealth << " health" << std::endl << std::endl;
							}
							else if (choice == 3) {
								std::cout << "You have encountered a " << y.getEnemy() << " it has ";
								std::cout << enemyHealth;
								std::cout << " health.";
								std::cout << " The " << y.getEnemy() << " has missed their attack! " << std::endl;
								std::cout << std::endl;
								humanHealth = humanHealth - y.getDamage(3);
								std::cout << "The enemy has missed, you still have " << humanHealth << " health" << std::endl << std::endl;
							}

							// PLAYER TURN

							std::cout << pName << " has had enough." << std::endl << std::endl;
							std::cout << "Please select from the following options to fight back the " << y.getEnemy() << std::endl << std::endl;
							std::cout << "1. Use Primary Weapon. 2. Punch with hands." << std::endl;
							std::cout << "3. Use Med Kit.        4. Do nothing." << std::endl << std::endl;
							std::cin >> playerinput;

							if (playerinput == 1) {
								std::cout << pName << " has used their primary weapon." << std::endl << std::endl;
								enemyHealth = enemyHealth - 10;
								std::cout << y.getEnemy() << " has taken damage, they now have " << enemyHealth << " health." << std::endl << std::endl;
							}
							if (playerinput == 2) {
								std::cout << pName << " has used their fist, and charged with a PUNCH!" << std::endl << std::endl;
								enemyHealth = enemyHealth - 5;
								std::cout << y.getEnemy() << " has taken damage, they now have " << enemyHealth << " health." << std::endl << std::endl;
							}
							if (playerinput == 3) {
								std::cout << pName << " felt like they were low on hp, and decided to use their med kit." << std::endl << std::endl;
								std::cout << pName << " has: " << medkits << " left." << std::endl;
								std::cout << pName << " now has: " << humanHealth << std::endl;
							}
							if (playerinput == 4) {
								std::cout << pName << " couldn't decided what to do, so they did what no one else would do. Nothing." << std::endl << std::endl;
							}
						} while (humanHealth > 0 && enemyHealth > 0);


						//system("cls"); //clears the console.
						std::cout << "[1]Continue" << std::endl;
						std::cin >> fourthChoice;

						//The following is the story continuing after the battle.  No need to code further for forest.

						//[2] Continue exploring the forest in another direction
						if (fourthChoice == 1) {
							system("cls"); //clears the console.
							std::cout << a.getForestStoryFour() << std::endl;
							std::cin >> fifthChoice;

							//[1] Listen to his plan
							if (fifthChoice == 1) {
								std::cout << a.getForestStoryFive() << std::endl;
								std::cin >> sixthChoice;

								//[1]Set a trap for the beast
								if (sixthChoice == 1) {
									std::cout << a.getForestStoryFiveOne() << std::endl;
									std::cin >> seventhChoice;

									//[1]Distract the beast
									if (seventhChoice == 1) {
										system("cls"); //clears the console.
										std::cout << a.getForestStoryFiveTwo() << std::endl;
										std::cin >> eigthChoice;

										//[1]Try to keep the beast in position
										if (eigthChoice == 1) {
											std::cout << a.getForestStoryFiveTwoOne() << std::endl;
											continueAdventure = false;
											//game over
											break;
										}

										//[2]Dodge the beast
										if (eigthChoice == 2) {
											std::cout << a.getForestStoryFiveTwoTwo() << std::endl;
											std::cin >> ninthChoice;

											//[1]Continue
											if (ninthChoice == 1) {
												std::cout << a.getForestStoryFiveTwoThree() << std::endl;
												std::cin >> tenthChoice;
												//finished this course of forest
												break;
											}
										}
									}
									//[2]Shoot the boulders
									if (seventhChoice == 2) {
										system("cls"); //clears the console.
										std::cout << a.getForestStoryFiveThree() << std::endl;
										std::cin >> eigthChoice;

										//[1]Shoot the boulders more
										if (sixthChoice == 1) {
											std::cout << a.getForestStoryFiveThreeOne() << std::endl;
											continueAdventure = false;
											//game over
											break;
										}

										//[2]Wait and see if the boulders fall
										if (sixthChoice == 2) {
											std::cout << a.getForestStoryFiveThreeTwo() << std::endl;
											std::cin >> seventhChoice;

											//[1]Continue
											if (seventhChoice == 1) {
												std::cout << a.getForestStoryFiveTwoThree() << std::endl;
												std::cin >> eigthChoice;
												//finished this course of forest
												break;
											}
										}
									}
								}
							}
						}
					}
				}

				//[2] Continue exploring the forest in another direction
				if (secondChoice == 2) {
					system("cls"); //clears the console.
					std::cout << a.getForestStoryFour() << std::endl;
					std::cin >> thirdChoice;

					//[1] Listen to his plan
					if (thirdChoice == 1) {
						std::cout << a.getForestStoryFive() << std::endl;
						std::cin >> fourthChoice;

						//[1]Set a trap for the beast
						if (fourthChoice == 1) {
							std::cout << a.getForestStoryFiveOne() << std::endl;
							std::cin >> fifthChoice;

							//[1]Distract the beast
							if (fifthChoice == 1) {
								system("cls"); //clears the console.
								std::cout << a.getForestStoryFiveTwo() << std::endl;
								std::cin >> sixthChoice;

								//[1]Try to keep the beast in position
								if (sixthChoice == 1) {
									std::cout << a.getForestStoryFiveTwoOne() << std::endl;
									continueAdventure = false;
									//game over
									break;
								}

								//[2]Dodge the beast
								if (sixthChoice == 2) {
									std::cout << a.getForestStoryFiveTwoTwo() << std::endl;
									std::cin >> seventhChoice;

									//[1]Continue
									if (seventhChoice == 1) {
										std::cout << a.getForestStoryFiveTwoThree() << std::endl;
										std::cin >> eigthChoice;
										//finished this course of forest
										break;
									}
								}
							}
							//[2]Shoot the boulders
							if (fifthChoice == 2) {
								system("cls"); //clears the console.
								std::cout << a.getForestStoryFiveThree() << std::endl;
								std::cin >> sixthChoice;

								//[1]Shoot the boulders more
								if (sixthChoice == 1) {
									std::cout << a.getForestStoryFiveThreeOne() << std::endl;
									continueAdventure = false;
									//game over
									break;
								}

								//[2]Wait and see if the boulders fall
								if (sixthChoice == 2) {
									std::cout << a.getForestStoryFiveThreeTwo() << std::endl;
									std::cin >> seventhChoice;

									//[1]Continue
									if (seventhChoice == 1) {
										std::cout << a.getForestStoryFiveTwoThree() << std::endl;
										std::cin >> eigthChoice;
										//finished this course of forest
										break;
									}
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				break;
			}
			break;
		}
	}
	// 2/7/2020 FOREST complete, finish with plains.  See notes below.

	// 2/11/2020 Plains completed by Joel A.  Modified by River C.
	if (continueAdventure == true) {
		switch (choice) {
		case 1:
			//insert this next code into places where person wants to check their inventory
			//cannot be made into seperate class
			system("cls"); //clears the console.
			h.setMedKit(true);
			h.setFusionPart(true);
			h.setLaserRifle(true);
			h.setShipPart(true);

			std::cout << "Here is your current inventory: " << std::endl;
			if (h.getMedKit() == true) {
				std::cout << "Medical kit: 1" << std::endl;
			}
			if (h.getFusionPistol() == true) {
				std::cout << "Fusion Pistol" << std::endl;
			}
			if (h.getLaserRifle() == true) {
				std::cout << "Laser Rifle" << std::endl;
			}
			if (h.getShipPart() == true) {
				std::cout << "Ship Parts: 2" << std::endl;
			}

			//to continue the story an option needs to be added to the end to continue
			std::cout << "[1] Continue journey" << std::endl;
			std::cin >> continueJourney;

			system("cls"); //clears the console.
			std::cout << b.getPlainsStoryOne() << std::endl;
			std::cin >> choice1;

			//[1]Continue traveling to the plains
			if (choice1 == 1) {
				system("cls");
				std::cout << b.getPlainsStoryTwo() << std::endl;
				std::cin >> choice2;

				//[1]Scream at lion

				if (choice2 == 1) {
					system("cls");

					std::cout << b.getPlainsStoryFour() << std::endl;
					break;
				}
				//[2]Runaway
				if (choice2 == 2) {
					system("cls");
					std::cout << b.getPlainsStoryThree() << std::endl;
					std::cin >> choice3;

					//[1] Continue Journey
					if (choice3 == 1) {
						system("cls");

						std::cout << b.getPlainsStoryFive() << std::endl;
						std::cin >> choice5;

						//[1]Step on snake
						if (choice5 == 1) {
							system("cls");
							std::cout << b.getPlainsStorySix() << std::endl;
							break;
						}
						//[2]Shoot snake
						if (choice5 == 2) {
							system("cls");
							std::cout << b.getPlainsStorySeven() << std::endl;
							std::cin >> choice6;

							//[1]Eat sanke
							if (choice6 == 1) {
								system("cls"); //clears the console.

								std::cout << b.getPlainsStoryEight() << std::endl;

								break;
							}
							//[2]Leave snake and Encounter Space wolf
							if (choice6 == 2) {
								system("cls");
								std::cout << b.getPlainsStoryNine() << std::endl;
								std::cin >> choice7;



								//[1]Sneak up on Space wolf
								if (choice7 == 1) {
									system("cls");
									std::cout << b.getPlainsStoryEleven() << std::endl;
									break;
								}
								//Call out Space wolf
								if (choice7 == 2) {
									system("cls");
									std::cout << b.getPlainsStoryTen() << std::endl;
									std::cin >> choice8;

									//[1]Pull out gun
									if (choice8 == 1) {
										system("cls");
										std::cout << b.getPlainsStoryTwelve() << std::endl;
										break;
									}
									//[2]Punch Space wolf
									if (choice8 == 2) {
										system("cls");
										std::cout << b.getPlainsStoryThirteen() << std::endl;
									}
								}
							}


						}
					}
				}
			}


		}
	}
	// 2/11/2020 Plains completed by Joel A.  Modified by River C.

	//Game notes for development 

	//include at least 1 stl  <-- #include <random> in RandomEncounter
	//include at least 2 classes

	//if 1 then cout story
	//else exit cmd

	//are you male or female
	//what is your name
	//...
	//Begin story
	//Go to planet, now start to have random encounters possible after each text choice.
	//make a class for RandomEncounter, based off a dice roll mechanic and if the 
	//right number is chosen then the encounter will occur, else the story continues.
	//Typical menu choice should be a desination, use an item, or return to ship.  Only
	//return to ship if all 3 peices are found.  If you have 3 peices and try to pick up
	//more, display a message like: "You do not need any more ship parts!".

	//If battle the character must select an item, a weapon or medkit.  Health will
	//be an int, and will be ++ or -- based on AI attack choice.  AI attack for enemy
	//characters should also be randomly based, like a dice roll, except 3 or 4 choices
	//can apply and something will always happen, unlike the RandomEncounter and only
	//one number chance causes it to be true and occur.

	//Spaceship needs 3 parts to be fixed, some enemies may be able to drop a part?
	//Enemies will need to be based off a character superclass perhaps.
	//Items will need to be a class(es) and have a string name and int damage value.
	//Make a medpack, Fusion Pistol, Laser Rifle, and Thermal Cannon.
	//When retrieved all pieces, return to the ship.
	//Put the peices in the ship and you fly back to home base.  Game Over, You win!
}
