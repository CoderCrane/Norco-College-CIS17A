//#include "pch.h"
#include <iostream>
#include "DayOfYear.h"
#include "Month.h"

int main()
{
	//I've tried to reference either class to find the day and month using the calculations we've made in class.
	//Although, I'm getting an error saying dayOfYear at the left of .print() in my cout statement must have a class.
	//I'm not sure how to fix this issue.  My intent is to enter an int input for dayOfYear to run through the class named dayOfYear.
	DayOfYear DayOfYear;
	int dayOfYear;
	std::cout << "Please enter a day of the year: " << std::endl;
	std::cin >> dayOfYear;
	
	std::cout << dayOfYear.print() << std::endl;
}
