#ifndef MONTH_H
#define MONTH_H
//#include "pch.h"
#include <string>

class Month {
private:
	int numOfDays;
	std::string name;

public:
	Month();
	Month(std::string, int);
	int getNumOfDays();
	std::string getName();
};

#endif