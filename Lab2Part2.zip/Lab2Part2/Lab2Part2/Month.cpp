//#include "pch.h"
#include "Month.h"
#include <string>

Month::Month() {
	// Do-nothing Month
}

Month::Month(std::string name, int numberOfDays) {
	this->name = name;
	this->numOfDays = numberOfDays;
}

int Month::getNumOfDays() {
	return this->numOfDays;
}

std::string Month::getName() {
	return this->name;
}