//#include "pch.h"
#include <iostream>
#include "DayOfYear.h"
#include "Month.h"

int main()
{
	//Similar errors as part 1, I believe I'm having an issue with linking what I want the user to input and the classes taking that input and computing it.
	//My intent is to prompt the user to enter the month, then the day.  The classes will then consider the date based on the data entered.
	DayOfYear DayOfYear;
	Month Month;
	int day;
	int month;
	std::cout << "Please enter a month: " << std::endl;
	std::cin >> month;  //If I use Month, then the >> recieves an error.

	std::cout << "Please enter a day: " << std::endl;
	std::cin >> day;

	std::cout << Month.getName() << day.getDOY() << std::endl;  //day.getDOY() has the same error as part 1.
}