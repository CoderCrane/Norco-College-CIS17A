//#include "pch.h"
#include "DayOfYear.h"
#include <iostream>
#include <sstream>

DayOfYear::DayOfYear() {
	// Do-nothing DayOfYear
}

DayOfYear::DayOfYear(std::string month, int dayOfMonth) {
	Month january("January", 31);
	Month feb("February", 28);
	Month mar("March", 31);
	Month apr("April", 30);
	Month may("May", 31);
	Month june("June", 30);
	Month july("July", 31);
	Month aug("August", 31);
	Month sep("September", 30);
	Month oct("October", 31);
	Month nov("November", 30);
	Month dec("December", 31);
	this->months[0] = january;
	this->months[1] = feb;
	this->months[2] = mar;
	this->months[3] = apr;
	this->months[4] = may;
	this->months[5] = june;
	this->months[6] = july;
	this->months[7] = aug;
	this->months[8] = sep;
	this->months[9] = oct;
	this->months[10] = nov;
	this->months[11] = dec;

	bool found = false;
	this->dayOfYear = 0;
	for (int i = 0; i < NUM_OF_MONTHS; i++) {
		if (month == this->months[i].getName()) {
			if (dayOfMonth >= this->months[i].getNumOfDays()) {
				std::cout << "Please enter a valid input." << std::endl;
				exit(-1);
			}
			this->dayOfYear += dayOfMonth;
			found = true;
		}
		else if (!found) {
			this->dayOfYear += this->months->getNumOfDays();
		}
	}
	if (!found) {
		std::cout << "Please enter a valid input." << std::endl;
		exit(-1);
	}
}

int DayOfYear::getDOY() {
	return this->dayOfYear;
}

DayOfYear::DayOfYear(int dayOfYear) {
	this->dayOfYear = dayOfYear;
	Month january("January", 31);
	Month feb("February", 28);
	Month mar("March", 31);
	Month apr("April", 30);
	Month may("May", 31);
	Month june("June", 30);
	Month july("July", 31);
	Month aug("August", 31);
	Month sep("September", 30);
	Month oct("October", 31);
	Month nov("November", 30);
	Month dec("December", 31);
	this->months[0] = january;
	this->months[1] = feb;
	this->months[2] = mar;
	this->months[3] = apr;
	this->months[4] = may;
	this->months[5] = june;
	this->months[6] = july;
	this->months[7] = aug;
	this->months[8] = sep;
	this->months[9] = oct;
	this->months[10] = nov;
	this->months[11] = dec;
}

std::string DayOfYear::print() {
	int numOfDaysLeft = this->dayOfYear;
	int monthCounter = 0;
	while (numOfDaysLeft > 0) {
		// Get days in current month;
		int daysInMonth = this->months[monthCounter].getNumOfDays();
		// if days in current month - days left is negative, 
		if (numOfDaysLeft - daysInMonth < 0) {
			// we're in the right month;
			std::stringstream output;
			output << this->months[monthCounter].getName() << " " << numOfDaysLeft;

			return output.str();
		}
		// otherwise, subtract days in month from days left and loop again
		numOfDaysLeft = numOfDaysLeft - daysInMonth;
		monthCounter++;
	}
}